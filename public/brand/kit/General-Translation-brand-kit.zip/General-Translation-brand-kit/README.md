# General Translation brand kit

The General Translation logo is a globe whose lines draw the letters G and T: one filled shape in one colour, drawn on a 256 unit square. **Katagami Text** is the brand's typeface for everything but code: the name in the logo, interface, headings and body. Geist Mono sets code. The palette is four absolute colours, ink, raised ink, titanium and paper, and one blue accent, which has a lighter form, the accent lift, for ink grounds. One more colour, motion off-white, is used only on ink: for the mark in the dark motion files and for text in an interface in dark mode.

Every logo file in this kit is generated from the one drawing of the mark and from the name's outlines, so the mark, the lockups, the frames and the icons agree exactly. Every SVG is outlined: no fonts, no live text, no embedded images.

Start with `guides/brand-sheet.png`, the brand on one page, and `guides/variant-sheet.png`, every image file in `logo/` and the motion posters on one page.

**Every transparent logo PNG is in `logo/transparent/`**, by type; the frames' transparent versions stay in their frame folders. Every transparent PNG is named `-on-transparent` (`-white-on-transparent` and `-accent-lift-on-transparent` for dark backgrounds), and every PNG not so named has a solid background: Google Drive and some previews draw transparency as black, so a white logo there looks like an empty black square.

## What is in the kit

| Folder | What it holds |
| --- | --- |
| `logo/` | The mark, the stacked and one-line lockups and the wordmarks, each as SVG, PDF and PNG (512, 1024 and 2048 px; the PNGs on a solid ground in each type's `png/`, the transparent ones in `logo/transparent/`); the web and app icons; social avatars and link cards |
| `frames/` | The logo centred in every common aspect ratio, from square posts to the X header and the LinkedIn banner |
| `color/` | The colour sheet, and the palette as JSON, CSS and an Adobe swatch file |
| `type/` | The type spec, and Katagami Text (desktop and web files) with its licence |
| `guides/` | The brand sheet, construction and clear space, minimum sizes and the variant sheet |
| `motion/` | The logo's loading loop and hover, on paper and on ink |

## Which file to use

- **Transparent is the default.** Every SVG and PDF of the mark, the lockups and the wordmarks without `-on-` in its name has a transparent background, and so does every file named `-on-transparent` (the PNGs in `logo/transparent/` and the frames' transparent versions): `ink` and `accent` for light backgrounds, `white` and `accent-lift` for dark ones.
- **On a ground.** Files named `-ink-on-paper`, `-paper-on-ink`, `-accent-on-paper` and `-accent-lift-on-ink` carry their own background and the full clear space as their margin, so they can be placed as they are. They include every PNG in each type's `png/` folder. Every icon and social image in `logo/icons/` and `logo/social/` carries a ground too, except `favicon.svg`, which is transparent and turns paper (`#ffffff`) in dark mode.
- **On a website or in an app:** the SVG. The `-currentcolor` SVG is the master: it takes the colour of the surrounding text, for inline SVG and icon systems.
- **In slides, documents and chat:** a PNG. 512 px for chat and documents, 1024 px for slides, 2048 px for anything large.
- **In print or design tools:** the PDF or the SVG.
- **For a post, a cover or a banner:** a file from `frames/` at the platform's size.

**Margins.** A transparent logo file is tight to the ink, with a margin of 2 percent of the ink's height or 0.5 percent of its width, whichever is larger, so it lines up with other elements; give it its clear space when you place it. The square files centre the mark in a square with its clear space on every side.

## The logo

**The mark** is the globe alone. Use it where the name already appears nearby, or where a square is needed: icons, avatars, small spaces.

## The lockups

The name is set in Katagami Text at weight 500, tracking 0, with the font's own kerning. Throughout, the unit is the name's cap height (the height of the T).

**Stacked lockup**, "General" over "Translation". This is the main logo.

- The two lines start at the same left edge of ink.
- The white space from the first line's baseline to the second line's cap line is R, 0.4627 cap. R is a word space plus the right side bearing of the T and the left side bearing of the G. (The gap between the name's two words on one line, from the l to the T, is wider: 0.4867 cap.) So the two baselines stand 1.4627 cap apart.
- The span from the first line's cap line to the second line's baseline is therefore 2.4627 cap.
- The mark is 1.1 times that span: 2.709 cap tall. It is centred on the span, so it reaches 0.123 cap above the cap line and the same below the baseline, as a round letter overshoots flat ones.
- The gap from the mark's ink to the G's ink is 0.8 cap, 1.73 times R.

**One-line lockup.** Use it where height is short: a header bar, a footer, a banner.

- The mark is 2.2 cap tall, centred on the cap band, so it stands 0.6 cap above the cap line and 0.6 cap below the baseline.
- Why 2.2: at that size the mark's ring is as thick as the name's stems. The ring is 6.57 percent of the mark's height and Katagami Text's stem at weight 500 is 0.1448 cap, so the ring matches the stem when the mark is 2.203 cap tall, rounded to 2.2.
- The gap from the mark's ink to the G's ink is 0.8 cap (1.73 times R), as in the stacked lockup.

**Wordmarks.** The name alone, on one line or stacked, in the same type and spacing as the lockups. Use them where the mark already appears nearby, or where a mark would be too small to read.

The construction of both lockups is drawn in `guides/clear-space.png`. Use the files; never rebuild a lockup by hand.

## Clear space

Keep a clear space of **X = 0.25 of the mark's height** on every side. In the stacked lockup X is 0.68 of the name's cap height; in the one-line lockup it is 0.55. A wordmark alone keeps 0.68 of its cap height, the space it has in the stacked lockup. No text, edge or other logo enters it.

## Minimum sizes

| Logo | Smallest size |
| --- | --- |
| Mark | 24 px tall when used alone. 16 px only for tab icons, where the mark fills the square: the ring reads, and the inner lines blur to grey |
| Stacked lockup | The name's cap height 9 px (the mark is then 24.4 px tall) |
| One-line lockup | The name's cap height 9 px (the mark is then 19.8 px tall) |
| Wordmark | Cap height 9 px |

In print, at 96 px to the inch, 24 px is 6.4 mm and a 9 px cap height is 2.4 mm. See `guides/minimum-size.png`.

## Colours

The logo is always one colour: ink on paper, paper on ink, accent on paper, or accent lift on ink. The one exception is the dark motion files, which draw the mark in motion off-white (`#f2f2f0`) on ink. On a photograph or a busy picture, put the logo on a plain ink or paper ground.

| Colour | Hex | RGB | HSL | OKLCH | Use |
| --- | --- | --- | --- | --- | --- |
| Ink | `#070707` | 7, 7, 7 | 0, 0%, 3% | `oklch(12.86% 0.0000 0.0)` | The logo and text on paper; the dark ground |
| Raised ink | `#101010` | 16, 16, 16 | 0, 0%, 6% | `oklch(17.30% 0.0000 0.0)` | The one raised surface on an ink ground: code, panels |
| Titanium | `#8a8f98` | 138, 143, 152 | 219, 6%, 57% | `oklch(64.88% 0.0146 262.4)` | Captions, counters and quiet labels on ink, or on paper at 24 px and up; never the logo |
| Paper | `#ffffff` | 255, 255, 255 | 0, 0%, 100% | `oklch(100.00% 0.0000 0.0)` | The light ground; the logo on ink |
| Accent | `#2f5ce0` | 47, 92, 224 | 225, 74%, 53% | `oklch(52.67% 0.2072 265.3)` | The one accent, on paper: small elements only; the logo on paper |
| Accent lift | `#86a8ff` | 134, 168, 255 | 223, 100%, 76% | `oklch(74.24% 0.1319 267.0)` | The accent on an ink ground; the logo on ink |
| Motion off-white | `#f2f2f0` | 242, 242, 240 | 60, 7%, 95% | `oklch(96.06% 0.0027 106.4)` | The mark in the dark motion files; the text colour of an interface in dark mode |

- The accent is `#2f5ce0` on paper and its lift `#86a8ff` on ink. Never put `#2f5ce0` on ink.
- The accent marks small elements: an active state, a link, one highlight. It never fills a large area.
- Motion off-white `#f2f2f0` is used only on ink: for the mark in the dark motion files, and for text in an interface in dark mode. Text on ink in print and images is paper.
- In file names, "white" is the paper colour `#ffffff` with no ground: every file named `white` is transparent.
- No gradients, shadows or other colours in the logo.

**Contrast** (WCAG 2):

| Pair | Ratio | Level | Use |
| --- | --- | --- | --- |
| Ink on paper | 20.14:1 | AAA | Logo and text on paper |
| Paper on ink | 20.14:1 | AAA | The logo on ink; text on ink in print and images |
| Accent on paper | 5.63:1 | AA | Logo or accent on paper |
| Accent lift on ink | 8.69:1 | AAA | Logo or accent on ink |
| Paper on raised ink | 19.03:1 | AAA | Text on a raised surface |
| Motion off-white on ink | 17.97:1 | AAA | The mark in the dark motion files; text in an interface in dark mode |
| Titanium on ink | 6.20:1 | AA | Captions on ink |
| Titanium on paper | 3.25:1 | AA for large text only | Captions on paper at 24 px and up only (under 4.5:1) |
| Accent on ink | 3.58:1 | AA for large text only | Never: use the accent lift on ink |

**Tailwind.** Tailwind CSS v4, in your main CSS file:

```css
@theme {
  --color-gt-ink: #070707;
  --color-gt-raised-ink: #101010;
  --color-gt-titanium: #8a8f98;
  --color-gt-paper: #ffffff;
  --color-gt-accent: #2f5ce0;
  --color-gt-accent-lift: #86a8ff;
  --color-gt-motion-off-white: #f2f2f0;
}
```

Tailwind CSS v3:

```js
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        gt: {
          'ink': '#070707',
          'raised-ink': '#101010',
          'titanium': '#8a8f98',
          'paper': '#ffffff',
          'accent': '#2f5ce0',
          'accent-lift': '#86a8ff',
          'motion-off-white': '#f2f2f0',
        },
      },
    },
  },
};
```

Either gives classes such as `bg-gt-ink`, `text-gt-paper` and `text-gt-accent`. `color/colors.css` has the same colours as plain CSS custom properties, and `color/colors.ase` loads them into Adobe apps as swatches.

## Type

**Katagami Text** sets everything but code: the name in the logo, interface, headings and body. Geist Mono sets code (below).

**In the logo.** The name is Katagami Text at weight 500, roman, tracking 0, with the font's own kerning and no other features. The logo files carry it as outlines, so nobody needs the font to use the logo. Never retype the name in place of a logo file.

**Everywhere else.** Katagami Text 1.200, roman and italic, variable with one axis, weight 100 to 900: 15,212 glyphs covering Latin, Greek, Cyrillic and 28 more scripts.

- **Weights.** 400 for running text. 500 for labels, headings, display text, `b` and `strong`. Nothing above 500 and nothing below 400.
- **Features.** The font's defaults are the brand's forms, so set no `font-feature-settings`. The defaults are Katagami's long-flag 1, a G with a spur and the compact f, a double-storey a, a round-topped 3, a closed 4, a 6 and 9 with curved stems, and punctuation with round dots. Each of these tags turns on a form the brand does not use. `cv01` ("Short-flag one") gives the short-flag 1; `cv10` ("Capital G without spur") gives a G without a spur; `cv12` ("Wide f") gives the wide f; `ss01` ("Open digits") gives the flat-top 3, open 4 and straight-stem 6 and 9 together (`cv09`, `cv02`, `cv03`, `cv04` one at a time); `ss03` ("Round quotes & commas") gives round quotes and commas; `ss07` ("Square punctuation") gives square dots in the punctuation, i and j; `cv11` ("Single-story a") gives a single-storey a. Tabular figures through `font-variant-numeric: tabular-nums`.
- **Size.** Katagami Text has no optical size axis: one design at every size. Set `font-weight`, never `font-variation-settings`.
- **Tracking.** -0.025em for titles 32 px and up, weight 500; -0.02em for large numbers and 24 px heads, weight 500; -0.015em for display quotes, 27 to 34 px, weight 400; -0.01em for labels, weight 500; -0.005em for group labels, weight 500; 0 for running text, weight 400. Nothing goes tighter than -0.025em.
- **Measure.** 60 to 70 characters a line (32em for body text). Headings wrap balanced.
- **Loading.** On the web, self-host `KatagamiText.woff2` and `KatagamiText-Italic.woff2` from `type/fonts/`. They are the full fonts, not subset. In desktop apps (slides, documents, design tools) install `KatagamiText[wght].ttf` and `KatagamiText-Italic[wght].ttf`.
- Licence: SIL Open Font License 1.1 (`type/fonts/Katagami-OFL.txt`). Source and the other members of the family: https://github.com/Kevin-Liu-01/Katagami.

**Geist Mono** sets code, tokens, terminals, file paths, hex values and locale codes, and nothing else: never a heading, a body line or a marketing line. Weight 400, tracking 0. It is not in this kit: get it from Google Fonts (fonts.google.com/specimen/Geist+Mono) or github.com/vercel/geist-font, under the SIL Open Font License 1.1.

```css
@font-face { font-family: 'Katagami Text'; src: url(KatagamiText.woff2) format('woff2'); font-weight: 100 900; font-style: normal; font-display: swap; }
@font-face { font-family: 'Katagami Text'; src: url(KatagamiText-Italic.woff2) format('woff2'); font-weight: 100 900; font-style: italic; font-display: swap; }
body { font-family: 'Katagami Text', system-ui, sans-serif; font-weight: 400; }
h1, h2 { font-weight: 500; text-wrap: balance; }
h1 { letter-spacing: -0.025em; } /* titles, 32 px and up */
h2 { letter-spacing: -0.02em; }  /* heads at 24 px */
b, strong { font-weight: 500; }
code, pre { font-family: 'Geist Mono', ui-monospace, monospace; }
```

See `type/type-spec.png`.

## Frames

`frames/` has the logo centred in each common aspect ratio, as SVG and PNG, in four versions each: on paper, on ink, and transparent in ink or in white (named `-ink-on-transparent` and `-white-on-transparent`; these stay in their frame's folder). Square and portrait frames carry the stacked lockup and the mark; landscape frames and the banners carry the one-line lockup as well, since their height is short. Every logo keeps its clear space inside the frame.

| Ratio | Size (px) | Use | Folder | Logo sizes (ink) |
| --- | --- | --- | --- | --- |
| 1:1 | 1080 by 1080 | Square post (Instagram, LinkedIn, X) | `frames/1x1-1080x1080/` | the stacked lockup 536 by 140 px; the mark 346 by 346 px |
| 4:5 | 1080 by 1350 | Portrait post (Instagram, LinkedIn) | `frames/4x5-1080x1350/` | the stacked lockup 536 by 140 px; the mark 346 by 346 px |
| 9:16 | 1080 by 1920 | Story, Reel or vertical video | `frames/9x16-1080x1920/` | the stacked lockup 536 by 140 px; the mark 346 by 346 px |
| 3:2 | 1500 by 1000 | Landscape picture, slide or print | `frames/3x2-1500x1000/` | the stacked lockup 806 by 210 px; the one-line lockup 806 by 117 px; the mark 320 by 320 px |
| 16:9 | 1920 by 1080 | Slide, video title card or screen | `frames/16x9-1920x1080/` | the stacked lockup 995 by 259 px; the one-line lockup 955 by 138 px; the mark 346 by 346 px |
| 1.91:1 | 1200 by 628 | Link card (LinkedIn, ads) | `frames/1.91x1-1200x628/` | the stacked lockup 578 by 151 px; the one-line lockup 555 by 80 px; the mark 201 by 201 px |
| 1.91:1 | 1200 by 630 | Link card (Open Graph, X, Facebook) | `frames/1.91x1-1200x630/` | the stacked lockup 580 by 151 px; the one-line lockup 557 by 81 px; the mark 202 by 202 px |
| 3:1 | 1500 by 500 | X header | `frames/3x1-1500x500/` | the one-line lockup 666 by 96 px; the stacked lockup 666 by 174 px; the mark 186 by 186 px |
| 4:1 | 1584 by 396 | LinkedIn banner | `frames/4x1-1584x396/` | the one-line lockup 792 by 115 px; the stacked lockup 561 by 146 px; the mark 146 by 146 px |

**Safe areas on the banners.** Platforms crop banners and cover part of them with the profile picture, and their layouts change, so the logo stays well inside:

- **X header, 1500 by 500.** The apps can crop about 100 px off the top and bottom on narrow screens, and the profile picture covers the lower left (to about x 375 from y 330). The logo stays inside the centre 740 by 300 px (x 380 to 1120, y 100 to 400).
- **LinkedIn banner, 1584 by 396.** The profile picture covers the lower left (to about x 350 from y 240 on desktop) and the apps crop the sides. The logo stays inside the centre 880 by 236 px (x 352 to 1232, y 80 to 316).

`frames/frames-sheet.png` shows every frame on paper and on ink, with the banners' safe areas dashed; the transparent versions match them.

## Do

- Use the logo files as supplied.
- Keep the clear space.
- Use the palette only, in the allowed pairs.
- On a photograph or a busy picture, give the logo a plain ink or paper ground.

## Do not

- Stretch, squash or skew the logo. Scale it only in proportion.
- Rotate it or tilt any part of it.
- Recolour it outside the palette, or use two colours, gradients or patterns in it.
- Add effects: shadows, glows, outlines, bevels, blurs or textures.
- Set the name in another typeface, weight or spacing, or retype it. Use the files.
- Rebuild a lockup by hand: never move the mark against the name or change its size in a lockup.
- Put the logo on a busy picture without a ground.

These are drawn as examples in `guides/brand-sheet.png`.

## Web icons

Copy `logo/icons/` to the site's root and add to the page's `<head>`:

```html
<link rel="icon" href="/favicon.ico" sizes="16x16 32x32 48x48">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
```

The favicon PNGs place the mark on whole pixels (16 of 16, 28 of 32, 42 of 48, 56 of 64 and 112 of 128 px), so its ring stays sharp.

## Motion

`motion/` holds the two loops the logo moves in, on paper and on ink: the loading loop (12 s), in which the meridian draws back, the G's line runs three laps round the globe and the meridian draws out again, and the hover (3.5 s), in which the meridian draws back along its oval and then draws out again. Both are 1080 px square at 60 fps, H.264. On ink the mark is motion off-white `#f2f2f0`. Play them muted and looped; the poster is the first frame.

## Licences

The logo and the brand are General Translation's. Katagami Text is a free font under the SIL Open Font License 1.1; its licence text sits next to it in `type/fonts/`. Geist Mono is not in this kit; it is also under the SIL Open Font License 1.1, and its licence text comes with the font from Google Fonts (fonts.google.com/specimen/Geist+Mono) or github.com/vercel/geist-font.

## Every file

472 files, including this README.

### The mark (`logo/mark/`)

| File | Use |
| --- | --- |
| `logo/mark/pdf/gt-mark-accent-lift.pdf` | The mark alone, accent lift (#86a8ff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-accent.pdf` | The mark alone, accent (#2f5ce0), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-ink.pdf` | The mark alone, ink (#070707), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-accent-lift-on-ink.pdf` | The mark centred on a square with its clear space, accent lift (#86a8ff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-accent-lift.pdf` | The mark centred on a square with its clear space, accent lift (#86a8ff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-accent-on-paper.pdf` | The mark centred on a square with its clear space, accent (#2f5ce0) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-accent.pdf` | The mark centred on a square with its clear space, accent (#2f5ce0), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-ink-on-paper.pdf` | The mark centred on a square with its clear space, ink (#070707) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-ink.pdf` | The mark centred on a square with its clear space, ink (#070707), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-paper-on-ink.pdf` | The mark centred on a square with its clear space, paper (#ffffff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-square-white.pdf` | The mark centred on a square with its clear space, white (#ffffff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/mark/pdf/gt-mark-white.pdf` | The mark alone, white (#ffffff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/mark/png/gt-mark-square-accent-lift-on-ink-1024.png` | The mark centred on a square with its clear space, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/mark/png/gt-mark-square-accent-lift-on-ink-2048.png` | The mark centred on a square with its clear space, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/mark/png/gt-mark-square-accent-lift-on-ink-512.png` | The mark centred on a square with its clear space, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/mark/png/gt-mark-square-accent-on-paper-1024.png` | The mark centred on a square with its clear space, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/mark/png/gt-mark-square-accent-on-paper-2048.png` | The mark centred on a square with its clear space, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/mark/png/gt-mark-square-accent-on-paper-512.png` | The mark centred on a square with its clear space, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/mark/png/gt-mark-square-ink-on-paper-1024.png` | The mark centred on a square with its clear space, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/mark/png/gt-mark-square-ink-on-paper-2048.png` | The mark centred on a square with its clear space, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/mark/png/gt-mark-square-ink-on-paper-512.png` | The mark centred on a square with its clear space, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/mark/png/gt-mark-square-paper-on-ink-1024.png` | The mark centred on a square with its clear space, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/mark/png/gt-mark-square-paper-on-ink-2048.png` | The mark centred on a square with its clear space, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/mark/png/gt-mark-square-paper-on-ink-512.png` | The mark centred on a square with its clear space, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/mark/svg/gt-mark-accent-lift.svg` | The mark alone, accent lift (#86a8ff), transparent, for dark grounds. Outlined vector |
| `logo/mark/svg/gt-mark-accent.svg` | The mark alone, accent (#2f5ce0), transparent, for light grounds. Outlined vector |
| `logo/mark/svg/gt-mark-currentcolor.svg` | The mark alone, in currentColor, the master: it takes the colour of the surrounding text, for inline SVG and icon systems. Outlined vector |
| `logo/mark/svg/gt-mark-ink.svg` | The mark alone, ink (#070707), transparent, for light grounds. Outlined vector |
| `logo/mark/svg/gt-mark-square-accent-lift-on-ink.svg` | The mark centred on a square with its clear space, accent lift (#86a8ff) on an ink (#070707) ground. Outlined vector |
| `logo/mark/svg/gt-mark-square-accent-lift.svg` | The mark centred on a square with its clear space, accent lift (#86a8ff), transparent, for dark grounds. Outlined vector |
| `logo/mark/svg/gt-mark-square-accent-on-paper.svg` | The mark centred on a square with its clear space, accent (#2f5ce0) on a paper (#ffffff) ground. Outlined vector |
| `logo/mark/svg/gt-mark-square-accent.svg` | The mark centred on a square with its clear space, accent (#2f5ce0), transparent, for light grounds. Outlined vector |
| `logo/mark/svg/gt-mark-square-currentcolor.svg` | The mark centred on a square with its clear space, in currentColor, the master: it takes the colour of the surrounding text, for inline SVG and icon systems. Outlined vector |
| `logo/mark/svg/gt-mark-square-ink-on-paper.svg` | The mark centred on a square with its clear space, ink (#070707) on a paper (#ffffff) ground. Outlined vector |
| `logo/mark/svg/gt-mark-square-ink.svg` | The mark centred on a square with its clear space, ink (#070707), transparent, for light grounds. Outlined vector |
| `logo/mark/svg/gt-mark-square-paper-on-ink.svg` | The mark centred on a square with its clear space, paper (#ffffff) on an ink (#070707) ground. Outlined vector |
| `logo/mark/svg/gt-mark-square-white.svg` | The mark centred on a square with its clear space, white (#ffffff), transparent, for dark grounds. Outlined vector |
| `logo/mark/svg/gt-mark-white.svg` | The mark alone, white (#ffffff), transparent, for dark grounds. Outlined vector |

### The stacked lockup (`logo/lockup-stacked/`)

| File | Use |
| --- | --- |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-accent-lift-on-ink.pdf` | The stacked lockup, accent lift (#86a8ff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-accent-lift.pdf` | The stacked lockup, accent lift (#86a8ff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-accent-on-paper.pdf` | The stacked lockup, accent (#2f5ce0) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-accent.pdf` | The stacked lockup, accent (#2f5ce0), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-ink-on-paper.pdf` | The stacked lockup, ink (#070707) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-ink.pdf` | The stacked lockup, ink (#070707), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-paper-on-ink.pdf` | The stacked lockup, paper (#ffffff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/lockup-stacked/pdf/gt-lockup-stacked-white.pdf` | The stacked lockup, white (#ffffff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/lockup-stacked/png/gt-lockup-stacked-accent-lift-on-ink-1024.png` | The stacked lockup, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-accent-lift-on-ink-2048.png` | The stacked lockup, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-accent-lift-on-ink-512.png` | The stacked lockup, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-accent-on-paper-1024.png` | The stacked lockup, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-accent-on-paper-2048.png` | The stacked lockup, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-accent-on-paper-512.png` | The stacked lockup, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-ink-on-paper-1024.png` | The stacked lockup, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-ink-on-paper-2048.png` | The stacked lockup, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-ink-on-paper-512.png` | The stacked lockup, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-paper-on-ink-1024.png` | The stacked lockup, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-paper-on-ink-2048.png` | The stacked lockup, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-stacked/png/gt-lockup-stacked-paper-on-ink-512.png` | The stacked lockup, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-stacked/svg/gt-lockup-stacked-accent-lift-on-ink.svg` | The stacked lockup, accent lift (#86a8ff) on an ink (#070707) ground. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-accent-lift.svg` | The stacked lockup, accent lift (#86a8ff), transparent, for dark grounds. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-accent-on-paper.svg` | The stacked lockup, accent (#2f5ce0) on a paper (#ffffff) ground. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-accent.svg` | The stacked lockup, accent (#2f5ce0), transparent, for light grounds. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-currentcolor.svg` | The stacked lockup, in currentColor, the master: it takes the colour of the surrounding text, for inline SVG and icon systems. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-ink-on-paper.svg` | The stacked lockup, ink (#070707) on a paper (#ffffff) ground. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-ink.svg` | The stacked lockup, ink (#070707), transparent, for light grounds. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-paper-on-ink.svg` | The stacked lockup, paper (#ffffff) on an ink (#070707) ground. Outlined vector |
| `logo/lockup-stacked/svg/gt-lockup-stacked-white.svg` | The stacked lockup, white (#ffffff), transparent, for dark grounds. Outlined vector |

### The one-line lockup (`logo/lockup-horizontal/`)

| File | Use |
| --- | --- |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-accent-lift-on-ink.pdf` | The one-line lockup, accent lift (#86a8ff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-accent-lift.pdf` | The one-line lockup, accent lift (#86a8ff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-accent-on-paper.pdf` | The one-line lockup, accent (#2f5ce0) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-accent.pdf` | The one-line lockup, accent (#2f5ce0), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-ink-on-paper.pdf` | The one-line lockup, ink (#070707) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-ink.pdf` | The one-line lockup, ink (#070707), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-paper-on-ink.pdf` | The one-line lockup, paper (#ffffff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/lockup-horizontal/pdf/gt-lockup-horizontal-white.pdf` | The one-line lockup, white (#ffffff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-accent-lift-on-ink-1024.png` | The one-line lockup, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-accent-lift-on-ink-2048.png` | The one-line lockup, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-accent-lift-on-ink-512.png` | The one-line lockup, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-accent-on-paper-1024.png` | The one-line lockup, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-accent-on-paper-2048.png` | The one-line lockup, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-accent-on-paper-512.png` | The one-line lockup, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-ink-on-paper-1024.png` | The one-line lockup, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-ink-on-paper-2048.png` | The one-line lockup, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-ink-on-paper-512.png` | The one-line lockup, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-paper-on-ink-1024.png` | The one-line lockup, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-paper-on-ink-2048.png` | The one-line lockup, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/lockup-horizontal/png/gt-lockup-horizontal-paper-on-ink-512.png` | The one-line lockup, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-accent-lift-on-ink.svg` | The one-line lockup, accent lift (#86a8ff) on an ink (#070707) ground. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-accent-lift.svg` | The one-line lockup, accent lift (#86a8ff), transparent, for dark grounds. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-accent-on-paper.svg` | The one-line lockup, accent (#2f5ce0) on a paper (#ffffff) ground. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-accent.svg` | The one-line lockup, accent (#2f5ce0), transparent, for light grounds. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-currentcolor.svg` | The one-line lockup, in currentColor, the master: it takes the colour of the surrounding text, for inline SVG and icon systems. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-ink-on-paper.svg` | The one-line lockup, ink (#070707) on a paper (#ffffff) ground. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-ink.svg` | The one-line lockup, ink (#070707), transparent, for light grounds. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-paper-on-ink.svg` | The one-line lockup, paper (#ffffff) on an ink (#070707) ground. Outlined vector |
| `logo/lockup-horizontal/svg/gt-lockup-horizontal-white.svg` | The one-line lockup, white (#ffffff), transparent, for dark grounds. Outlined vector |

### The wordmarks (`logo/wordmark/`)

| File | Use |
| --- | --- |
| `logo/wordmark/pdf/gt-wordmark-accent-lift-on-ink.pdf` | The one-line wordmark, accent lift (#86a8ff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-accent-lift.pdf` | The one-line wordmark, accent lift (#86a8ff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-accent-on-paper.pdf` | The one-line wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-accent.pdf` | The one-line wordmark, accent (#2f5ce0), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-ink-on-paper.pdf` | The one-line wordmark, ink (#070707) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-ink.pdf` | The one-line wordmark, ink (#070707), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-paper-on-ink.pdf` | The one-line wordmark, paper (#ffffff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-accent-lift-on-ink.pdf` | The stacked wordmark, accent lift (#86a8ff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-accent-lift.pdf` | The stacked wordmark, accent lift (#86a8ff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-accent-on-paper.pdf` | The stacked wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-accent.pdf` | The stacked wordmark, accent (#2f5ce0), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-ink-on-paper.pdf` | The stacked wordmark, ink (#070707) on a paper (#ffffff) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-ink.pdf` | The stacked wordmark, ink (#070707), transparent, for light grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-paper-on-ink.pdf` | The stacked wordmark, paper (#ffffff) on an ink (#070707) ground. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-stacked-white.pdf` | The stacked wordmark, white (#ffffff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/wordmark/pdf/gt-wordmark-white.pdf` | The one-line wordmark, white (#ffffff), transparent, for dark grounds. Vector PDF for print and design tools |
| `logo/wordmark/png/gt-wordmark-accent-lift-on-ink-1024.png` | The one-line wordmark, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-accent-lift-on-ink-2048.png` | The one-line wordmark, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-accent-lift-on-ink-512.png` | The one-line wordmark, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-accent-on-paper-1024.png` | The one-line wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-accent-on-paper-2048.png` | The one-line wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-accent-on-paper-512.png` | The one-line wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-ink-on-paper-1024.png` | The one-line wordmark, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-ink-on-paper-2048.png` | The one-line wordmark, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-ink-on-paper-512.png` | The one-line wordmark, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-paper-on-ink-1024.png` | The one-line wordmark, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-paper-on-ink-2048.png` | The one-line wordmark, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-paper-on-ink-512.png` | The one-line wordmark, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-accent-lift-on-ink-1024.png` | The stacked wordmark, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-accent-lift-on-ink-2048.png` | The stacked wordmark, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-accent-lift-on-ink-512.png` | The stacked wordmark, accent lift (#86a8ff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-accent-on-paper-1024.png` | The stacked wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-accent-on-paper-2048.png` | The stacked wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-accent-on-paper-512.png` | The stacked wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-ink-on-paper-1024.png` | The stacked wordmark, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-ink-on-paper-2048.png` | The stacked wordmark, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-ink-on-paper-512.png` | The stacked wordmark, ink (#070707) on a paper (#ffffff) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-paper-on-ink-1024.png` | The stacked wordmark, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 1024 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-paper-on-ink-2048.png` | The stacked wordmark, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 2048 px on the long side |
| `logo/wordmark/png/gt-wordmark-stacked-paper-on-ink-512.png` | The stacked wordmark, paper (#ffffff) on an ink (#070707) ground. PNG on its ground, 512 px on the long side |
| `logo/wordmark/svg/gt-wordmark-accent-lift-on-ink.svg` | The one-line wordmark, accent lift (#86a8ff) on an ink (#070707) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-accent-lift.svg` | The one-line wordmark, accent lift (#86a8ff), transparent, for dark grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-accent-on-paper.svg` | The one-line wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-accent.svg` | The one-line wordmark, accent (#2f5ce0), transparent, for light grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-currentcolor.svg` | The one-line wordmark, in currentColor, the master: it takes the colour of the surrounding text, for inline SVG and icon systems. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-ink-on-paper.svg` | The one-line wordmark, ink (#070707) on a paper (#ffffff) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-ink.svg` | The one-line wordmark, ink (#070707), transparent, for light grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-paper-on-ink.svg` | The one-line wordmark, paper (#ffffff) on an ink (#070707) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-accent-lift-on-ink.svg` | The stacked wordmark, accent lift (#86a8ff) on an ink (#070707) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-accent-lift.svg` | The stacked wordmark, accent lift (#86a8ff), transparent, for dark grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-accent-on-paper.svg` | The stacked wordmark, accent (#2f5ce0) on a paper (#ffffff) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-accent.svg` | The stacked wordmark, accent (#2f5ce0), transparent, for light grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-currentcolor.svg` | The stacked wordmark, in currentColor, the master: it takes the colour of the surrounding text, for inline SVG and icon systems. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-ink-on-paper.svg` | The stacked wordmark, ink (#070707) on a paper (#ffffff) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-ink.svg` | The stacked wordmark, ink (#070707), transparent, for light grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-paper-on-ink.svg` | The stacked wordmark, paper (#ffffff) on an ink (#070707) ground. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-stacked-white.svg` | The stacked wordmark, white (#ffffff), transparent, for dark grounds. Outlined vector |
| `logo/wordmark/svg/gt-wordmark-white.svg` | The one-line wordmark, white (#ffffff), transparent, for dark grounds. Outlined vector |

### Transparent PNGs (`logo/transparent/`)

| File | Use |
| --- | --- |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-accent-lift-on-transparent-1024.png` | The one-line lockup, accent lift (#86a8ff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-accent-lift-on-transparent-2048.png` | The one-line lockup, accent lift (#86a8ff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-accent-lift-on-transparent-512.png` | The one-line lockup, accent lift (#86a8ff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-accent-on-transparent-1024.png` | The one-line lockup, accent (#2f5ce0), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-accent-on-transparent-2048.png` | The one-line lockup, accent (#2f5ce0), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-accent-on-transparent-512.png` | The one-line lockup, accent (#2f5ce0), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-ink-on-transparent-1024.png` | The one-line lockup, ink (#070707), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-ink-on-transparent-2048.png` | The one-line lockup, ink (#070707), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-ink-on-transparent-512.png` | The one-line lockup, ink (#070707), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-white-on-transparent-1024.png` | The one-line lockup, white (#ffffff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-white-on-transparent-2048.png` | The one-line lockup, white (#ffffff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-horizontal/gt-lockup-horizontal-white-on-transparent-512.png` | The one-line lockup, white (#ffffff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-accent-lift-on-transparent-1024.png` | The stacked lockup, accent lift (#86a8ff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-accent-lift-on-transparent-2048.png` | The stacked lockup, accent lift (#86a8ff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-accent-lift-on-transparent-512.png` | The stacked lockup, accent lift (#86a8ff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-accent-on-transparent-1024.png` | The stacked lockup, accent (#2f5ce0), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-accent-on-transparent-2048.png` | The stacked lockup, accent (#2f5ce0), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-accent-on-transparent-512.png` | The stacked lockup, accent (#2f5ce0), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-ink-on-transparent-1024.png` | The stacked lockup, ink (#070707), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-ink-on-transparent-2048.png` | The stacked lockup, ink (#070707), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-ink-on-transparent-512.png` | The stacked lockup, ink (#070707), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-white-on-transparent-1024.png` | The stacked lockup, white (#ffffff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-white-on-transparent-2048.png` | The stacked lockup, white (#ffffff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/lockup-stacked/gt-lockup-stacked-white-on-transparent-512.png` | The stacked lockup, white (#ffffff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-accent-lift-on-transparent-1024.png` | The mark alone, accent lift (#86a8ff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-accent-lift-on-transparent-2048.png` | The mark alone, accent lift (#86a8ff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-accent-lift-on-transparent-512.png` | The mark alone, accent lift (#86a8ff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-accent-on-transparent-1024.png` | The mark alone, accent (#2f5ce0), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-accent-on-transparent-2048.png` | The mark alone, accent (#2f5ce0), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-accent-on-transparent-512.png` | The mark alone, accent (#2f5ce0), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-ink-on-transparent-1024.png` | The mark alone, ink (#070707), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-ink-on-transparent-2048.png` | The mark alone, ink (#070707), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-ink-on-transparent-512.png` | The mark alone, ink (#070707), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-square-accent-lift-on-transparent-1024.png` | The mark centred on a square with its clear space, accent lift (#86a8ff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-square-accent-lift-on-transparent-2048.png` | The mark centred on a square with its clear space, accent lift (#86a8ff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-square-accent-lift-on-transparent-512.png` | The mark centred on a square with its clear space, accent lift (#86a8ff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-square-accent-on-transparent-1024.png` | The mark centred on a square with its clear space, accent (#2f5ce0), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-square-accent-on-transparent-2048.png` | The mark centred on a square with its clear space, accent (#2f5ce0), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-square-accent-on-transparent-512.png` | The mark centred on a square with its clear space, accent (#2f5ce0), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-square-ink-on-transparent-1024.png` | The mark centred on a square with its clear space, ink (#070707), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-square-ink-on-transparent-2048.png` | The mark centred on a square with its clear space, ink (#070707), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-square-ink-on-transparent-512.png` | The mark centred on a square with its clear space, ink (#070707), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-square-white-on-transparent-1024.png` | The mark centred on a square with its clear space, white (#ffffff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-square-white-on-transparent-2048.png` | The mark centred on a square with its clear space, white (#ffffff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-square-white-on-transparent-512.png` | The mark centred on a square with its clear space, white (#ffffff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/mark/gt-mark-white-on-transparent-1024.png` | The mark alone, white (#ffffff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/mark/gt-mark-white-on-transparent-2048.png` | The mark alone, white (#ffffff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/mark/gt-mark-white-on-transparent-512.png` | The mark alone, white (#ffffff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-accent-lift-on-transparent-1024.png` | The one-line wordmark, accent lift (#86a8ff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-accent-lift-on-transparent-2048.png` | The one-line wordmark, accent lift (#86a8ff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-accent-lift-on-transparent-512.png` | The one-line wordmark, accent lift (#86a8ff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-accent-on-transparent-1024.png` | The one-line wordmark, accent (#2f5ce0), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-accent-on-transparent-2048.png` | The one-line wordmark, accent (#2f5ce0), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-accent-on-transparent-512.png` | The one-line wordmark, accent (#2f5ce0), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-ink-on-transparent-1024.png` | The one-line wordmark, ink (#070707), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-ink-on-transparent-2048.png` | The one-line wordmark, ink (#070707), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-ink-on-transparent-512.png` | The one-line wordmark, ink (#070707), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-accent-lift-on-transparent-1024.png` | The stacked wordmark, accent lift (#86a8ff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-accent-lift-on-transparent-2048.png` | The stacked wordmark, accent lift (#86a8ff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-accent-lift-on-transparent-512.png` | The stacked wordmark, accent lift (#86a8ff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-accent-on-transparent-1024.png` | The stacked wordmark, accent (#2f5ce0), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-accent-on-transparent-2048.png` | The stacked wordmark, accent (#2f5ce0), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-accent-on-transparent-512.png` | The stacked wordmark, accent (#2f5ce0), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-ink-on-transparent-1024.png` | The stacked wordmark, ink (#070707), transparent, for light grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-ink-on-transparent-2048.png` | The stacked wordmark, ink (#070707), transparent, for light grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-ink-on-transparent-512.png` | The stacked wordmark, ink (#070707), transparent, for light grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-white-on-transparent-1024.png` | The stacked wordmark, white (#ffffff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-white-on-transparent-2048.png` | The stacked wordmark, white (#ffffff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-stacked-white-on-transparent-512.png` | The stacked wordmark, white (#ffffff), transparent, for dark grounds. PNG, 512 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-white-on-transparent-1024.png` | The one-line wordmark, white (#ffffff), transparent, for dark grounds. PNG, 1024 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-white-on-transparent-2048.png` | The one-line wordmark, white (#ffffff), transparent, for dark grounds. PNG, 2048 px on the long side |
| `logo/transparent/wordmark/gt-wordmark-white-on-transparent-512.png` | The one-line wordmark, white (#ffffff), transparent, for dark grounds. PNG, 512 px on the long side |

### Icons (`logo/icons/`)

| File | Use |
| --- | --- |
| `logo/icons/android-chrome-192.png` | Android and web app icon, 192 px, on ink, mark 0.64 of the side |
| `logo/icons/android-chrome-512.png` | Android and web app icon, 512 px, on ink, mark 0.64 of the side |
| `logo/icons/app-icon-1024.png` | App icon, 1024 px, full bleed ink (the platform rounds the corners), mark 0.6 of the side |
| `logo/icons/app-icon-1024.svg` | The app icon as a vector |
| `logo/icons/apple-touch-icon.png` | iOS home screen icon, 180 px: the mark in paper on ink, 0.64 of the side |
| `logo/icons/favicon-128.png` | Tab and bookmark icon, 128 px: the mark in paper, 112 px tall, on an ink square |
| `logo/icons/favicon-16.png` | Tab and bookmark icon, 16 px: the mark in paper, 16 px tall, on an ink square |
| `logo/icons/favicon-32.png` | Tab and bookmark icon, 32 px: the mark in paper, 28 px tall, on an ink square |
| `logo/icons/favicon-48.png` | Tab and bookmark icon, 48 px: the mark in paper, 42 px tall, on an ink square |
| `logo/icons/favicon-64.png` | Tab and bookmark icon, 64 px: the mark in paper, 56 px tall, on an ink square |
| `logo/icons/favicon.ico` | Browser tab icon at 16, 32 and 48 px: the mark in paper on an ink square |
| `logo/icons/favicon.svg` | Browser tab icon as a vector: ink, and paper when the browser is in dark mode |
| `logo/icons/maskable-512.png` | Maskable web app icon, 512 px: the mark 0.56 of the side, inside the 80 percent safe circle |
| `logo/icons/site.webmanifest` | Web app manifest naming the Android and maskable icons; serve it from the site root |

### Social (`logo/social/`)

| File | Use |
| --- | --- |
| `logo/social/avatar-ink-1000.png` | Profile picture, 1000 px, on ink: the mark 0.6 of the side, safe for a circular crop |
| `logo/social/avatar-ink-400.png` | Profile picture, 400 px, on ink: the mark 0.6 of the side, safe for a circular crop |
| `logo/social/avatar-ink.svg` | Profile picture on ink, as a vector |
| `logo/social/avatar-paper-1000.png` | Profile picture, 1000 px, on paper: the mark 0.6 of the side, safe for a circular crop |
| `logo/social/avatar-paper-400.png` | Profile picture, 400 px, on paper: the mark 0.6 of the side, safe for a circular crop |
| `logo/social/avatar-paper.svg` | Profile picture on paper, as a vector |
| `logo/social/og-ink-1200x630.png` | Link preview card (Open Graph and X), 1200 by 630, the stacked lockup centred on ink, its mark 180 px tall |
| `logo/social/og-ink-1200x630.svg` | Link preview card on ink, as a vector |
| `logo/social/og-paper-1200x630.png` | Link preview card (Open Graph and X), 1200 by 630, the stacked lockup centred on paper, its mark 180 px tall |
| `logo/social/og-paper-1200x630.svg` | Link preview card on paper, as a vector |

### Frames (`frames/`)

| File | Use |
| --- | --- |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-ink-on-transparent.png` | Link card (LinkedIn, ads): the one-line lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-ink-on-transparent.svg` | Link card (LinkedIn, ads): the one-line lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-on-ink.png` | Link card (LinkedIn, ads): the one-line lockup centred, paper on an ink ground. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-on-ink.svg` | Link card (LinkedIn, ads): the one-line lockup centred, paper on an ink ground. Vector |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-on-paper.png` | Link card (LinkedIn, ads): the one-line lockup centred, ink on a paper ground. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-on-paper.svg` | Link card (LinkedIn, ads): the one-line lockup centred, ink on a paper ground. Vector |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-white-on-transparent.png` | Link card (LinkedIn, ads): the one-line lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-horizontal-1200x628-white-on-transparent.svg` | Link card (LinkedIn, ads): the one-line lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-ink-on-transparent.png` | Link card (LinkedIn, ads): the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-ink-on-transparent.svg` | Link card (LinkedIn, ads): the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-on-ink.png` | Link card (LinkedIn, ads): the stacked lockup centred, paper on an ink ground. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-on-ink.svg` | Link card (LinkedIn, ads): the stacked lockup centred, paper on an ink ground. Vector |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-on-paper.png` | Link card (LinkedIn, ads): the stacked lockup centred, ink on a paper ground. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-on-paper.svg` | Link card (LinkedIn, ads): the stacked lockup centred, ink on a paper ground. Vector |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-white-on-transparent.png` | Link card (LinkedIn, ads): the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-lockup-stacked-1200x628-white-on-transparent.svg` | Link card (LinkedIn, ads): the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1.91x1-1200x628/gt-mark-1200x628-ink-on-transparent.png` | Link card (LinkedIn, ads): the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-mark-1200x628-ink-on-transparent.svg` | Link card (LinkedIn, ads): the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1.91x1-1200x628/gt-mark-1200x628-on-ink.png` | Link card (LinkedIn, ads): the mark centred, paper on an ink ground. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-mark-1200x628-on-ink.svg` | Link card (LinkedIn, ads): the mark centred, paper on an ink ground. Vector |
| `frames/1.91x1-1200x628/gt-mark-1200x628-on-paper.png` | Link card (LinkedIn, ads): the mark centred, ink on a paper ground. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-mark-1200x628-on-paper.svg` | Link card (LinkedIn, ads): the mark centred, ink on a paper ground. Vector |
| `frames/1.91x1-1200x628/gt-mark-1200x628-white-on-transparent.png` | Link card (LinkedIn, ads): the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1200 by 628 |
| `frames/1.91x1-1200x628/gt-mark-1200x628-white-on-transparent.svg` | Link card (LinkedIn, ads): the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-ink-on-transparent.png` | Link card (Open Graph, X, Facebook): the one-line lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-ink-on-transparent.svg` | Link card (Open Graph, X, Facebook): the one-line lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-on-ink.png` | Link card (Open Graph, X, Facebook): the one-line lockup centred, paper on an ink ground. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-on-ink.svg` | Link card (Open Graph, X, Facebook): the one-line lockup centred, paper on an ink ground. Vector |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-on-paper.png` | Link card (Open Graph, X, Facebook): the one-line lockup centred, ink on a paper ground. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-on-paper.svg` | Link card (Open Graph, X, Facebook): the one-line lockup centred, ink on a paper ground. Vector |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-white-on-transparent.png` | Link card (Open Graph, X, Facebook): the one-line lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-horizontal-1200x630-white-on-transparent.svg` | Link card (Open Graph, X, Facebook): the one-line lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-ink-on-transparent.png` | Link card (Open Graph, X, Facebook): the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-ink-on-transparent.svg` | Link card (Open Graph, X, Facebook): the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-on-ink.png` | Link card (Open Graph, X, Facebook): the stacked lockup centred, paper on an ink ground. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-on-ink.svg` | Link card (Open Graph, X, Facebook): the stacked lockup centred, paper on an ink ground. Vector |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-on-paper.png` | Link card (Open Graph, X, Facebook): the stacked lockup centred, ink on a paper ground. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-on-paper.svg` | Link card (Open Graph, X, Facebook): the stacked lockup centred, ink on a paper ground. Vector |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-white-on-transparent.png` | Link card (Open Graph, X, Facebook): the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-lockup-stacked-1200x630-white-on-transparent.svg` | Link card (Open Graph, X, Facebook): the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1.91x1-1200x630/gt-mark-1200x630-ink-on-transparent.png` | Link card (Open Graph, X, Facebook): the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-mark-1200x630-ink-on-transparent.svg` | Link card (Open Graph, X, Facebook): the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1.91x1-1200x630/gt-mark-1200x630-on-ink.png` | Link card (Open Graph, X, Facebook): the mark centred, paper on an ink ground. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-mark-1200x630-on-ink.svg` | Link card (Open Graph, X, Facebook): the mark centred, paper on an ink ground. Vector |
| `frames/1.91x1-1200x630/gt-mark-1200x630-on-paper.png` | Link card (Open Graph, X, Facebook): the mark centred, ink on a paper ground. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-mark-1200x630-on-paper.svg` | Link card (Open Graph, X, Facebook): the mark centred, ink on a paper ground. Vector |
| `frames/1.91x1-1200x630/gt-mark-1200x630-white-on-transparent.png` | Link card (Open Graph, X, Facebook): the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1200 by 630 |
| `frames/1.91x1-1200x630/gt-mark-1200x630-white-on-transparent.svg` | Link card (Open Graph, X, Facebook): the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-ink-on-transparent.png` | Slide, video title card or screen: the one-line lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-ink-on-transparent.svg` | Slide, video title card or screen: the one-line lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-on-ink.png` | Slide, video title card or screen: the one-line lockup centred, paper on an ink ground. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-on-ink.svg` | Slide, video title card or screen: the one-line lockup centred, paper on an ink ground. Vector |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-on-paper.png` | Slide, video title card or screen: the one-line lockup centred, ink on a paper ground. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-on-paper.svg` | Slide, video title card or screen: the one-line lockup centred, ink on a paper ground. Vector |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-white-on-transparent.png` | Slide, video title card or screen: the one-line lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-horizontal-1920x1080-white-on-transparent.svg` | Slide, video title card or screen: the one-line lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-ink-on-transparent.png` | Slide, video title card or screen: the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-ink-on-transparent.svg` | Slide, video title card or screen: the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-on-ink.png` | Slide, video title card or screen: the stacked lockup centred, paper on an ink ground. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-on-ink.svg` | Slide, video title card or screen: the stacked lockup centred, paper on an ink ground. Vector |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-on-paper.png` | Slide, video title card or screen: the stacked lockup centred, ink on a paper ground. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-on-paper.svg` | Slide, video title card or screen: the stacked lockup centred, ink on a paper ground. Vector |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-white-on-transparent.png` | Slide, video title card or screen: the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-lockup-stacked-1920x1080-white-on-transparent.svg` | Slide, video title card or screen: the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/16x9-1920x1080/gt-mark-1920x1080-ink-on-transparent.png` | Slide, video title card or screen: the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-mark-1920x1080-ink-on-transparent.svg` | Slide, video title card or screen: the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/16x9-1920x1080/gt-mark-1920x1080-on-ink.png` | Slide, video title card or screen: the mark centred, paper on an ink ground. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-mark-1920x1080-on-ink.svg` | Slide, video title card or screen: the mark centred, paper on an ink ground. Vector |
| `frames/16x9-1920x1080/gt-mark-1920x1080-on-paper.png` | Slide, video title card or screen: the mark centred, ink on a paper ground. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-mark-1920x1080-on-paper.svg` | Slide, video title card or screen: the mark centred, ink on a paper ground. Vector |
| `frames/16x9-1920x1080/gt-mark-1920x1080-white-on-transparent.png` | Slide, video title card or screen: the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1920 by 1080 |
| `frames/16x9-1920x1080/gt-mark-1920x1080-white-on-transparent.svg` | Slide, video title card or screen: the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-ink-on-transparent.png` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-ink-on-transparent.svg` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-on-ink.png` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, paper on an ink ground. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-on-ink.svg` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, paper on an ink ground. Vector |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-on-paper.png` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, ink on a paper ground. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-on-paper.svg` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, ink on a paper ground. Vector |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-white-on-transparent.png` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-lockup-stacked-1080x1080-white-on-transparent.svg` | Square post (Instagram, LinkedIn, X): the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/1x1-1080x1080/gt-mark-1080x1080-ink-on-transparent.png` | Square post (Instagram, LinkedIn, X): the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-mark-1080x1080-ink-on-transparent.svg` | Square post (Instagram, LinkedIn, X): the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/1x1-1080x1080/gt-mark-1080x1080-on-ink.png` | Square post (Instagram, LinkedIn, X): the mark centred, paper on an ink ground. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-mark-1080x1080-on-ink.svg` | Square post (Instagram, LinkedIn, X): the mark centred, paper on an ink ground. Vector |
| `frames/1x1-1080x1080/gt-mark-1080x1080-on-paper.png` | Square post (Instagram, LinkedIn, X): the mark centred, ink on a paper ground. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-mark-1080x1080-on-paper.svg` | Square post (Instagram, LinkedIn, X): the mark centred, ink on a paper ground. Vector |
| `frames/1x1-1080x1080/gt-mark-1080x1080-white-on-transparent.png` | Square post (Instagram, LinkedIn, X): the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1080 by 1080 |
| `frames/1x1-1080x1080/gt-mark-1080x1080-white-on-transparent.svg` | Square post (Instagram, LinkedIn, X): the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-ink-on-transparent.png` | X header: the one-line lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-ink-on-transparent.svg` | X header: the one-line lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-on-ink.png` | X header: the one-line lockup centred, paper on an ink ground. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-on-ink.svg` | X header: the one-line lockup centred, paper on an ink ground. Vector |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-on-paper.png` | X header: the one-line lockup centred, ink on a paper ground. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-on-paper.svg` | X header: the one-line lockup centred, ink on a paper ground. Vector |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-white-on-transparent.png` | X header: the one-line lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-horizontal-1500x500-white-on-transparent.svg` | X header: the one-line lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-ink-on-transparent.png` | X header: the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-ink-on-transparent.svg` | X header: the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-on-ink.png` | X header: the stacked lockup centred, paper on an ink ground. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-on-ink.svg` | X header: the stacked lockup centred, paper on an ink ground. Vector |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-on-paper.png` | X header: the stacked lockup centred, ink on a paper ground. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-on-paper.svg` | X header: the stacked lockup centred, ink on a paper ground. Vector |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-white-on-transparent.png` | X header: the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-lockup-stacked-1500x500-white-on-transparent.svg` | X header: the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/3x1-1500x500/gt-mark-1500x500-ink-on-transparent.png` | X header: the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-mark-1500x500-ink-on-transparent.svg` | X header: the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/3x1-1500x500/gt-mark-1500x500-on-ink.png` | X header: the mark centred, paper on an ink ground. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-mark-1500x500-on-ink.svg` | X header: the mark centred, paper on an ink ground. Vector |
| `frames/3x1-1500x500/gt-mark-1500x500-on-paper.png` | X header: the mark centred, ink on a paper ground. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-mark-1500x500-on-paper.svg` | X header: the mark centred, ink on a paper ground. Vector |
| `frames/3x1-1500x500/gt-mark-1500x500-white-on-transparent.png` | X header: the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1500 by 500 |
| `frames/3x1-1500x500/gt-mark-1500x500-white-on-transparent.svg` | X header: the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-ink-on-transparent.png` | Landscape picture, slide or print: the one-line lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-ink-on-transparent.svg` | Landscape picture, slide or print: the one-line lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-on-ink.png` | Landscape picture, slide or print: the one-line lockup centred, paper on an ink ground. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-on-ink.svg` | Landscape picture, slide or print: the one-line lockup centred, paper on an ink ground. Vector |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-on-paper.png` | Landscape picture, slide or print: the one-line lockup centred, ink on a paper ground. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-on-paper.svg` | Landscape picture, slide or print: the one-line lockup centred, ink on a paper ground. Vector |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-white-on-transparent.png` | Landscape picture, slide or print: the one-line lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-horizontal-1500x1000-white-on-transparent.svg` | Landscape picture, slide or print: the one-line lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-ink-on-transparent.png` | Landscape picture, slide or print: the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-ink-on-transparent.svg` | Landscape picture, slide or print: the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-on-ink.png` | Landscape picture, slide or print: the stacked lockup centred, paper on an ink ground. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-on-ink.svg` | Landscape picture, slide or print: the stacked lockup centred, paper on an ink ground. Vector |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-on-paper.png` | Landscape picture, slide or print: the stacked lockup centred, ink on a paper ground. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-on-paper.svg` | Landscape picture, slide or print: the stacked lockup centred, ink on a paper ground. Vector |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-white-on-transparent.png` | Landscape picture, slide or print: the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-lockup-stacked-1500x1000-white-on-transparent.svg` | Landscape picture, slide or print: the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/3x2-1500x1000/gt-mark-1500x1000-ink-on-transparent.png` | Landscape picture, slide or print: the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-mark-1500x1000-ink-on-transparent.svg` | Landscape picture, slide or print: the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/3x2-1500x1000/gt-mark-1500x1000-on-ink.png` | Landscape picture, slide or print: the mark centred, paper on an ink ground. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-mark-1500x1000-on-ink.svg` | Landscape picture, slide or print: the mark centred, paper on an ink ground. Vector |
| `frames/3x2-1500x1000/gt-mark-1500x1000-on-paper.png` | Landscape picture, slide or print: the mark centred, ink on a paper ground. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-mark-1500x1000-on-paper.svg` | Landscape picture, slide or print: the mark centred, ink on a paper ground. Vector |
| `frames/3x2-1500x1000/gt-mark-1500x1000-white-on-transparent.png` | Landscape picture, slide or print: the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1500 by 1000 |
| `frames/3x2-1500x1000/gt-mark-1500x1000-white-on-transparent.svg` | Landscape picture, slide or print: the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-ink-on-transparent.png` | LinkedIn banner: the one-line lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-ink-on-transparent.svg` | LinkedIn banner: the one-line lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-on-ink.png` | LinkedIn banner: the one-line lockup centred, paper on an ink ground. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-on-ink.svg` | LinkedIn banner: the one-line lockup centred, paper on an ink ground. Vector |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-on-paper.png` | LinkedIn banner: the one-line lockup centred, ink on a paper ground. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-on-paper.svg` | LinkedIn banner: the one-line lockup centred, ink on a paper ground. Vector |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-white-on-transparent.png` | LinkedIn banner: the one-line lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-horizontal-1584x396-white-on-transparent.svg` | LinkedIn banner: the one-line lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-ink-on-transparent.png` | LinkedIn banner: the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-ink-on-transparent.svg` | LinkedIn banner: the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-on-ink.png` | LinkedIn banner: the stacked lockup centred, paper on an ink ground. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-on-ink.svg` | LinkedIn banner: the stacked lockup centred, paper on an ink ground. Vector |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-on-paper.png` | LinkedIn banner: the stacked lockup centred, ink on a paper ground. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-on-paper.svg` | LinkedIn banner: the stacked lockup centred, ink on a paper ground. Vector |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-white-on-transparent.png` | LinkedIn banner: the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-lockup-stacked-1584x396-white-on-transparent.svg` | LinkedIn banner: the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/4x1-1584x396/gt-mark-1584x396-ink-on-transparent.png` | LinkedIn banner: the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-mark-1584x396-ink-on-transparent.svg` | LinkedIn banner: the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/4x1-1584x396/gt-mark-1584x396-on-ink.png` | LinkedIn banner: the mark centred, paper on an ink ground. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-mark-1584x396-on-ink.svg` | LinkedIn banner: the mark centred, paper on an ink ground. Vector |
| `frames/4x1-1584x396/gt-mark-1584x396-on-paper.png` | LinkedIn banner: the mark centred, ink on a paper ground. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-mark-1584x396-on-paper.svg` | LinkedIn banner: the mark centred, ink on a paper ground. Vector |
| `frames/4x1-1584x396/gt-mark-1584x396-white-on-transparent.png` | LinkedIn banner: the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1584 by 396 |
| `frames/4x1-1584x396/gt-mark-1584x396-white-on-transparent.svg` | LinkedIn banner: the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-ink-on-transparent.png` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-ink-on-transparent.svg` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-on-ink.png` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, paper on an ink ground. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-on-ink.svg` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, paper on an ink ground. Vector |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-on-paper.png` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, ink on a paper ground. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-on-paper.svg` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, ink on a paper ground. Vector |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-white-on-transparent.png` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-lockup-stacked-1080x1350-white-on-transparent.svg` | Portrait post (Instagram, LinkedIn): the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/4x5-1080x1350/gt-mark-1080x1350-ink-on-transparent.png` | Portrait post (Instagram, LinkedIn): the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-mark-1080x1350-ink-on-transparent.svg` | Portrait post (Instagram, LinkedIn): the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/4x5-1080x1350/gt-mark-1080x1350-on-ink.png` | Portrait post (Instagram, LinkedIn): the mark centred, paper on an ink ground. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-mark-1080x1350-on-ink.svg` | Portrait post (Instagram, LinkedIn): the mark centred, paper on an ink ground. Vector |
| `frames/4x5-1080x1350/gt-mark-1080x1350-on-paper.png` | Portrait post (Instagram, LinkedIn): the mark centred, ink on a paper ground. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-mark-1080x1350-on-paper.svg` | Portrait post (Instagram, LinkedIn): the mark centred, ink on a paper ground. Vector |
| `frames/4x5-1080x1350/gt-mark-1080x1350-white-on-transparent.png` | Portrait post (Instagram, LinkedIn): the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1080 by 1350 |
| `frames/4x5-1080x1350/gt-mark-1080x1350-white-on-transparent.svg` | Portrait post (Instagram, LinkedIn): the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-ink-on-transparent.png` | Story, Reel or vertical video: the stacked lockup centred, ink on a transparent ground, for light backgrounds. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-ink-on-transparent.svg` | Story, Reel or vertical video: the stacked lockup centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-on-ink.png` | Story, Reel or vertical video: the stacked lockup centred, paper on an ink ground. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-on-ink.svg` | Story, Reel or vertical video: the stacked lockup centred, paper on an ink ground. Vector |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-on-paper.png` | Story, Reel or vertical video: the stacked lockup centred, ink on a paper ground. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-on-paper.svg` | Story, Reel or vertical video: the stacked lockup centred, ink on a paper ground. Vector |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-white-on-transparent.png` | Story, Reel or vertical video: the stacked lockup centred, white on a transparent ground, for dark backgrounds. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-lockup-stacked-1080x1920-white-on-transparent.svg` | Story, Reel or vertical video: the stacked lockup centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/9x16-1080x1920/gt-mark-1080x1920-ink-on-transparent.png` | Story, Reel or vertical video: the mark centred, ink on a transparent ground, for light backgrounds. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-mark-1080x1920-ink-on-transparent.svg` | Story, Reel or vertical video: the mark centred, ink on a transparent ground, for light backgrounds. Vector |
| `frames/9x16-1080x1920/gt-mark-1080x1920-on-ink.png` | Story, Reel or vertical video: the mark centred, paper on an ink ground. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-mark-1080x1920-on-ink.svg` | Story, Reel or vertical video: the mark centred, paper on an ink ground. Vector |
| `frames/9x16-1080x1920/gt-mark-1080x1920-on-paper.png` | Story, Reel or vertical video: the mark centred, ink on a paper ground. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-mark-1080x1920-on-paper.svg` | Story, Reel or vertical video: the mark centred, ink on a paper ground. Vector |
| `frames/9x16-1080x1920/gt-mark-1080x1920-white-on-transparent.png` | Story, Reel or vertical video: the mark centred, white on a transparent ground, for dark backgrounds. PNG, 1080 by 1920 |
| `frames/9x16-1080x1920/gt-mark-1080x1920-white-on-transparent.svg` | Story, Reel or vertical video: the mark centred, white on a transparent ground, for dark backgrounds. Vector |
| `frames/frames-sheet.png` | Every frame on paper and on ink on one contact sheet, with the banners' safe areas dashed |

### Colour (`color/`)

| File | Use |
| --- | --- |
| `color/color-sheet.pdf` | The colour sheet as a PDF |
| `color/color-sheet.png` | The palette with hex, RGB, HSL and OKLCH values and the contrast ratios of the pairs |
| `color/colors.ase` | The palette as Adobe Swatch Exchange, for Illustrator, Photoshop, InDesign and Affinity: one group of global RGB swatches |
| `color/colors.css` | The palette as CSS custom properties (--gt-ink and the rest), in hex and in OKLCH |
| `color/colors.json` | The palette as data: every colour in hex, RGB, HSL and OKLCH with its role, and the contrast pairs |

### Type (`type/`)

| File | Use |
| --- | --- |
| `type/fonts/Katagami-OFL.txt` | Katagami's licence: SIL Open Font License 1.1 |
| `type/fonts/KatagamiText-Italic.woff2` | Katagami Text italic for the web: self-host this file. Every glyph, feature and the weight axis, not subset |
| `type/fonts/KatagamiText-Italic[wght].ttf` | Katagami Text 1.200 italic for desktop apps (TrueType, variable, weight 100 to 900) |
| `type/fonts/KatagamiText.woff2` | Katagami Text roman for the web: self-host this file. Every glyph, feature and the weight axis, not subset |
| `type/fonts/KatagamiText[wght].ttf` | Katagami Text 1.200 roman for desktop apps: install it to set slides, documents and designs (TrueType, variable, weight 100 to 900) |
| `type/type-spec.pdf` | The type spec as a PDF |
| `type/type-spec.png` | The type spec: Katagami Text for everything but code, with its weights, features and tracking, and Geist Mono for code |

### Guides (`guides/`)

| File | Use |
| --- | --- |
| `guides/brand-sheet.pdf` | The brand sheet as a PDF |
| `guides/brand-sheet.png` | The brand on one page: the logo, the lockups, the colours, the type, and dos and don'ts |
| `guides/clear-space.pdf` | Construction and clear space as a PDF |
| `guides/clear-space.png` | The construction of both lockups, and the clear space around every logo |
| `guides/minimum-size.pdf` | Minimum sizes as a PDF |
| `guides/minimum-size.png` | Minimum sizes, each shown at its real pixel size and enlarged |
| `guides/variant-sheet.pdf` | The variant sheet as a PDF |
| `guides/variant-sheet.png` | Every image file in logo/ on one page, with the motion posters |

### Motion (`motion/`)

| File | Use |
| --- | --- |
| `motion/gt-hover-dark-poster.png` | Poster frame for the dark hover loop (the logo at rest; the same image as the dark loader poster) |
| `motion/gt-hover-dark.mp4` | Hover on ink, the mark in motion off-white (#f2f2f0): the meridian draws back along its oval and out again, 3.5 s, 1080 px square, 60 fps |
| `motion/gt-hover-light-poster.png` | Poster frame for the light hover loop (the logo at rest; the same image as the light loader poster) |
| `motion/gt-hover-light.mp4` | Hover on paper: the meridian draws back along its oval and out again, 3.5 s, 1080 px square, 60 fps |
| `motion/gt-loader-dark-poster.png` | Poster frame for the dark loading loop (the logo at rest; the same image as the dark hover poster) |
| `motion/gt-loader-dark.mp4` | Loading loop on ink, the mark in motion off-white (#f2f2f0): the meridian draws back, the G's line runs three laps round the globe, and the meridian draws out again, 12 s, 1080 px square, 60 fps, loops seamlessly |
| `motion/gt-loader-light-poster.png` | Poster frame for the light loading loop (the logo at rest; the same image as the light hover poster) |
| `motion/gt-loader-light.mp4` | Loading loop on paper: the meridian draws back, the G's line runs three laps round the globe, and the meridian draws out again, 12 s, 1080 px square, 60 fps, loops seamlessly |
